#!/bin/bash

# run via MPI on 4 parallel processes
mpirun -n 4 python example_other_08_spectra_via_MPI.py
