Because the optimization runtime can be rather long (several minutes to 10th of minutes),  
the evolutionary optimization examples are split in two parts: 

(1) The script to run the actual optimization 

(2) A script to analyze the optimization result (suffix "b" in numbering)

