output folder for evolutionary optimization results
