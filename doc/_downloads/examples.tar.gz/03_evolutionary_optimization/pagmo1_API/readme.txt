This folder contains examples for the old EO api, which was based on pagmo/pygmo V1.X. 

the scripts are deprecated and only tested in python 2.7
